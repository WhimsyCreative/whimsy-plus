<?php
/*
 * Plugin Name: Whimsy+ | Layout
 * Version: 0.0.2
 * Plugin URI: http://www.whimsycreative.co/framework/plus
 * Description: A plugin packed with awesome features for Whimsy Framework.
 * Author: Whimsy Creative Co.
 * Author URI: http://www.whimsycreative.co
 * Requires at least: 4.0
 * Tested up to: 4.8
 *
 * Text Domain: whimsy-plus
 * Domain Path: /language/
 *
 * @package WordPress
 * @author Natasha Cozad
 * @since 1.0.0
 */

 if ( !class_exists( 'WhimsyPlusLayout' ) ) {

	/**
	 * @since  1.0.0
	 * @access public
	 */
	class WhimsyPlusLayout {

		/**
		 * @since  1.0.0
		 * @access public
		 * @return void
		 */
		function __construct() {
        
			global $whimsypluslayout;

			/* Set up an empty class for the global $whimsypluslayout object. */
			$whimsypluslayout = new stdClass;

			/* Define framework, parent theme, and child theme constants. */
			add_action( 'init', array( $this, 'fields' ), 50 );

			/* Enqueue necessary scripts and CSS files for the skins . */
            //add_action( 'wp_enqueue_scripts', array( $this, 'enqueue' ), 200 );
            
        }
   
		/**
		 * @since  1.0.0
		 * @access public
		 * @return void
		 */
				
		function fields() {
			if( class_exists( 'Kirki' ) ) {
				/* Layout */
				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'slider',
					'settings'    => 'layout_size',
					'label'       => __( 'Site Width', 'whimsy-plus' ),
					'description' => __( 'Set the width of the whole body of the site in %.', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => '100',
					'priority'    => 1,
					'output'      => array(
						array(
							'element'  => '#page',
							'units'    => '%',
							'property' => 'width',
						),
					),
					'transport'   => 'auto',
					'js_vars'     => array(
						array(
							'element'  => '#page',
							'property' => 'width',
							'units'    => '%',
							'function' => 'css',
						),
					),
				) );
				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'radio-image',
					'settings'    => 'whimsy_framework_layout',
					'label'       => __( 'Global Layout', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => 'content-sidebar',
					'priority'    => 10,
					'choices'     => array(
						'sidebar-content'   => get_template_directory_uri() . '/library/img/sidebar-content.png',
						'full-width' => get_template_directory_uri() . '/library/img/full-width.png',
						'content-sidebar'  => get_template_directory_uri() . '/library/img/content-sidebar.png',
					),
				) );

				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'background',
					'settings'    => 'whimsy_plus_basic_bg_color',
					'label'       => __( 'Background', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => array(
						'background-color'    => '#ffffff',
						'background-image'    => '',
						'background-repeat'   => 'no-repeat',
						'background-size'     => 'cover',
						'background-attach'   => 'fixed',
						'background-position' => 'left-top',
						'background-opacity'  => 90,
					),
					'output'      => array(
						array(
							'element'  => 'body',
						),
					),
				) );
				
				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'toggle',
					'settings'    => 'box_layout',
					'label'       => __( 'Enable Box layout?', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => false,
					'priority'    => 10,
				) );

				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'background',
					'settings'    => 'boxed_website_background',
					'label'       => __( 'Box Layout Content Background', 'kirki' ),
					'description' => __( 'Content area background for #page.', 'kirki' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => array(
						'background-color'    => '#ffffff',
						'background-image'    => '',
						'background-repeat'   => 'no-repeat',
						'background-size'     => 'cover',
						'background-attach'   => 'fixed',
						'background-position' => 'left-top',
						'background-opacity'  => 90,
					),
					'priority'		 => 10,
					'active_callback'  => array(
						array(
						'setting'  => 'box_layout',
						'operator' => '==',
						'value'    => true
						),
					),
					'output'		 => array(
						array(
							'element' => '#page',
						),
					),
				) );
				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'dimension',
					'settings'    => 'box_layout_margin',
					'label'       => __( 'Margin', 'whimsy-plus' ),
					'description' => __( 'This controls how much blank space is between the sides of the browser window and your content.', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => '0 auto',
					'priority'    => 13,
					'active_callback'  => array(
						array(
						'setting'  => 'box_layout',
						'operator' => '==',
						'value'    => true
						),
					),
					'output'      => array(
						array(
							'element'  => '#page',
							'property' => 'margin',
						),
					),
					'transport'   => 'postMessage',
					'js_vars'     => array(
						array(
							'element'  => '#page',
							'property' => 'margin',
							'function' => 'css',
						),
					),
				) );
				Kirki::add_field( 'whimsy_plus', array(
					'type'        => 'dimension',
					'settings'    => 'box_layout_border_radius',
					'label'       => __( 'Border Radius', 'whimsy-plus' ),
					'description' => __( 'This will curve the corners of the box layout.', 'whimsy-plus' ),
					'section'     => 'whimsy_plus_layout',
					'default'     => '0',
					'priority'    => 14,
					'active_callback'  => array(
						array(
						'setting'  => 'box_layout',
						'operator' => '==',
						'value'    => true,
						),
					),
					'output'      => array(
						array(
							'element'  => '#page',
							'property' => 'border-radius',
						),
					),
					'transport'    => 'postMessage',
					'js_vars'      => array(
						array(
							'element'  => '#page',
							'property' => 'border-radius',
							'function' => 'css',
						),
					)
				) );
			}
		}
        /**
         * Include additional styles when in admin.
         */
        function enqueue() {

            $whimsy_framework_layout = get_theme_mod( 'whimsy_framework_layout' );
            
            if ( $whimsy_framework_layout  == 'sidebar-content' ) {
                wp_enqueue_style( 'whimsy-layout-sidebar-content', WHIMSY_CSS . 'layouts/sidebar-content.css' );
            }
            if ( $whimsy_framework_layout  == 'full-width' ) {
                wp_enqueue_style( 'whimsy-layout-full-width', WHIMSY_CSS . 'layouts/full-width.css' );
            }
        }
    }
}

$whimsypluslayout = new WhimsyPlusLayout();